import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Pickaxe, 
  Store, 
  Trophy, 
  Hammer, 
  MessageSquare, 
  Settings, 
  TrendingUp, 
  Backpack, 
  Zap, 
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ArrowRight,
  Archive,
  Lock as LockIcon,
  Cat,
  Dog,
  Ghost,
  Crown,
  Flame,
  Star,
  Bot
} from 'lucide-react';
import { auth, db } from './lib/firebase';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged,
  User
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  onSnapshot, 
  collection, 
  query, 
  orderBy, 
  limit,
  serverTimestamp,
  updateDoc
} from 'firebase/firestore';
import { 
  OreType, 
  UserData, 
  Upgrades, 
  GameEvent, 
  OperationType,
  FirestoreErrorInfo,
  OreSize,
  ORE_SIZE_MULTIPLIERS,
  BossOre 
} from './types';
import { 
  ORES, 
  UPGRADE_CONFIGS, 
  ACHIEVEMENTS, 
  CRAFTING_RECIPES, 
  PRESTIGE_RECIPES,
  TITLES, 
  AVATAR_ICONS,
  XP_BASE,
  XP_PER_ORE,
  EVENTS,
  EVENT_SHOP,
  MUTATIONS
} from './constants/gameData';
import { askCaveAssistant } from './services/gemini';

// --- Error Handler ---
function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

const ADMIN_EMAILS = ['sanyaoluadewale@gmail.com'];

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [gameState, setGameState] = useState<UserData | null>(null);
  const [activeTab, setActiveTab] = useState<'mining' | 'shop' | 'crafting' | 'leaderboard' | 'ai' | 'profile' | 'inventory' | 'events'>('mining');
  const [loading, setLoading] = useState(true);
  const [activeEvent, setActiveEvent] = useState<GameEvent | null>(null);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [isGuest, setIsGuest] = useState(false);
  const [showRestartModal, setShowRestartModal] = useState(false);
  const [restartInput, setRestartInput] = useState('');
  const [activeBoss, setActiveBoss] = useState<BossOre | null>(null);
  const [leaderboardCategory, setLeaderboardCategory] = useState<'wealth' | 'mined' | 'playtime' | 'level'>('wealth');
  const [playtimeSeconds, setPlaytimeSeconds] = useState(0);
  const [activeEvents, setActiveEvents] = useState<UserData['activeEvents']>([]);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [nextEventCountdown, setNextEventCountdown] = useState("");

  // --- Auth & Data Loading ---
  useEffect(() => {
    const unsub = setInterval(() => {
      if (gameState?.nextEventTime) {
        const diff = gameState.nextEventTime - Date.now();
        if (diff <= 0) {
          setNextEventCountdown("READY");
        } else {
          const h = Math.floor(diff / 3600000);
          const m = Math.floor((diff % 3600000) / 60000);
          const s = Math.floor((diff % 60000) / 1000);
          setNextEventCountdown(`${h}h ${m}m ${s}s`);
        }
      }
    }, 1000);
    return () => clearInterval(unsub);
  }, [gameState?.nextEventTime]);

  // --- Auth & Data Loading ---
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (u) {
        // We don't set loading false until data is back
        loadUserData(u.uid);
      } else {
        setLoading(false);
        setGameState(null);
      }
    });

    const unsubscribeEvent = onSnapshot(doc(db, 'global', 'activeEvent'), (snapshot) => {
      if (snapshot.exists()) {
        setActiveEvent(snapshot.data() as GameEvent);
      }
    }, (error) => {
      // Gracefully handle or report
      console.warn("Global event listener error:", error);
    });

    return () => {
      unsubscribeAuth();
      unsubscribeEvent();
    };
  }, []);

  useEffect(() => {
    if (gameState) {
      setPlaytimeSeconds(gameState.playtime || 0);
    }
  }, [gameState?.uid]);

  useEffect(() => {
    if (!user || !gameState) return;
    
    const interval = setInterval(() => {
      setPlaytimeSeconds(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, [user, !!gameState]);

  // Sync playtime back to server periodically
  useEffect(() => {
    if (!user || !gameState) return;
    const interval = setInterval(() => {
        updateDoc(doc(db, 'users', user.uid), {
            playtime: playtimeSeconds,
            lastActive: serverTimestamp()
        }).catch(err => console.error("Playtime sync error:", err));
    }, 30000); // Every 30 seconds

    return () => clearInterval(interval);
  }, [user, !!gameState, playtimeSeconds]);

  // Separate effect for auth-dependent listeners
  useEffect(() => {
    if (!user) {
      setLeaderboard([]);
      return;
    }

    const field = leaderboardCategory === 'wealth' ? 'money' : 
                  leaderboardCategory === 'mined' ? 'totalResourcesMined' : 
                  leaderboardCategory === 'level' ? 'level' : 'playtime';
    
    const leaderboardQuery = query(collection(db, 'users'), orderBy(field, 'desc'), limit(15));
    const unsubscribeLeaderboard = onSnapshot(leaderboardQuery, (snapshot) => {
      const data = snapshot.docs.map(d => ({ id: d.id, ...d.data() }));
      setLeaderboard(data);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'users');
    });

    return unsubscribeLeaderboard;
  }, [user, leaderboardCategory]);

  const loadUserData = async (uid: string) => {
    try {
      const docRef = doc(db, 'users', uid);
      const docSnap = await getDoc(docRef);

      if (docSnap.exists()) {
        const data = docSnap.data() as UserData;
        // Migration for old users
        if (!data.resourceWeights) data.resourceWeights = {};
        if (data.level === undefined) data.level = 1;
        if (data.xp === undefined) data.xp = 0;
        if (data.prestige === undefined) data.prestige = 0;
        if (data.hasCompletedTutorial === undefined) data.hasCompletedTutorial = false;
        if (data.nextEventTime === undefined) {
            data.nextEventTime = Date.now() + 7200000;
            const evIds = Object.keys(EVENTS);
            data.nextEventId = evIds[Math.floor(Math.random() * evIds.length)];
        }
        if (!data.mutations) data.mutations = [];
        if (!data.multipliers) data.multipliers = { gold: 1, luck: 1, xp: 1, strength: 1 };
        if (!data.vaultResources) data.vaultResources = {};
        if (!data.activeEvents) data.activeEvents = [];
        setGameState(data);
      } else {
        // Initial setup
        const initialData: UserData = {
          uid,
          displayName: auth.currentUser?.displayName || 'Miner',
          money: 0,
          resources: {
            [OreType.COAL]: 0,
            [OreType.IRON]: 0,
            [OreType.GOLD]: 0,
            [OreType.SAPPHIRE]: 0,
            [OreType.RUBY]: 0,
            [OreType.EMERALD]: 0,
            [OreType.DIAMOND]: 0,
            [OreType.OBSIDIAN]: 0,
            [OreType.MYTHRIL]: 0,
            [OreType.ADAMANTITE]: 0,
            [OreType.CRYSTAL]: 0
          },
          resourceWeights: {},
          upgrades: {
            strength: 1,
            luck: 1,
            backpack: 5,
            multiMine: 1
          },
          achievements: [],
          totalResourcesMined: 0,
          level: 1,
          xp: 0,
          prestige: 0,
          hasCompletedTutorial: false,
          multipliers: { gold: 1, luck: 1, xp: 1, strength: 1 },
          nextEventTime: Date.now() + 7200000,
          nextEventId: Object.keys(EVENTS)[Math.floor(Math.random() * Object.keys(EVENTS).length)],
          playtime: 0,
          lastLogin: Date.now(),
          profileCustomization: {
            title: 'Dirt Digester',
            avatarColor: '#3b82f6',
            avatarIcon: 'miner'
          },
          mutations: [],
          vaultResources: {},
          activeEvents: []
        };
        await setDoc(docRef, initialData);
        setGameState(initialData);
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.GET, `users/${uid}`);
    } finally {
      setLoading(false);
    }
  };

  const saveGameState = async (newState: UserData) => {
    if (!user || isGuest) return;
    try {
      await setDoc(doc(db, 'users', user.uid), newState);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  const login = async () => {
    setLoading(true);
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    try {
      await signInWithPopup(auth, provider);
      setIsGuest(false);
    } catch (e) {
      console.error("Login failed:", e);
      setIsGuest(false);
      setUser(null);
      setGameState(null);
      setLoading(false);
    }
  };

  const enterAsGuest = () => {
    setIsGuest(true);
    const initialData: UserData = {
        uid: 'guest',
        displayName: 'Guest Miner',
        money: 0,
        resources: {
            [OreType.COAL]: 0,
            [OreType.IRON]: 0,
            [OreType.GOLD]: 0,
            [OreType.SAPPHIRE]: 0,
            [OreType.RUBY]: 0,
            [OreType.EMERALD]: 0,
            [OreType.DIAMOND]: 0,
            [OreType.OBSIDIAN]: 0,
            [OreType.MYTHRIL]: 0,
            [OreType.ADAMANTITE]: 0,
            [OreType.CRYSTAL]: 0
        },
        resourceWeights: {},
        upgrades: { strength: 1, luck: 1, backpack: 10, multiMine: 1 },
        achievements: [],
        totalResourcesMined: 0,
        level: 1,
        xp: 0,
        prestige: 0,
        hasCompletedTutorial: false,
        multipliers: { gold: 1, luck: 1, xp: 1, strength: 1 },
        nextEventTime: Date.now() + 7200000,
        nextEventId: Object.keys(EVENTS)[Math.floor(Math.random() * Object.keys(EVENTS).length)],
        playtime: 0,
        lastLogin: Date.now(),
        mutations: [],
        vaultResources: {},
        activeEvents: [],
        profileCustomization: {
            avatarIcon: "⛏️",
            avatarColor: "#3b82f6",
            title: "Guest"
        }
    };
    setGameState(initialData);
  };

  const restartTycoon = async () => {
    if (restartInput === 'RESTART' && user) {
      const initialData: UserData = {
        uid: user.uid,
        displayName: user.displayName || 'Miner',
        money: 0,
        resources: {
          [OreType.COAL]: 0,
          [OreType.IRON]: 0,
          [OreType.GOLD]: 0,
          [OreType.SAPPHIRE]: 0,
          [OreType.RUBY]: 0,
          [OreType.EMERALD]: 0,
          [OreType.DIAMOND]: 0,
          [OreType.OBSIDIAN]: 0,
          [OreType.MYTHRIL]: 0,
          [OreType.ADAMANTITE]: 0,
          [OreType.CRYSTAL]: 0
        },
        resourceWeights: {},
        upgrades: {
          strength: 1,
          luck: 1,
          backpack: 5,
          multiMine: 1
        },
        achievements: [],
        totalResourcesMined: 0,
        level: 1,
        xp: 0,
        prestige: 0,
        hasCompletedTutorial: false,
        multipliers: { gold: 1, luck: 1, xp: 1, strength: 1 },
        nextEventTime: Date.now() + 7200000,
        nextEventId: Object.keys(EVENTS)[Math.floor(Math.random() * Object.keys(EVENTS).length)],
        playtime: 0,
        lastLogin: Date.now(),
        profileCustomization: {
            title: 'Dirt Digester',
            avatarColor: '#3b82f6',
            avatarIcon: 'miner'
        },
        mutations: [],
        vaultResources: {},
        activeEvents: []
      };
      await setDoc(doc(db, 'users', user.uid), initialData);
      setGameState(initialData);
      setShowRestartModal(false);
      setRestartInput('');
      setActiveBoss(null);
    }
  };

  const skipBoss = () => {
    setActiveBoss(null);
  };

  // --- Mining Logic ---
  const [lastMinedInfo, setLastMinedInfo] = useState<{name: string, size: string, color: string}[]>([]);

  const mineOre = (x: number, y: number) => {
    if (!gameState) return;

    const totalHeld = (Object.values(gameState.resources) as number[]).reduce((a, b) => a + b, 0);
    if (totalHeld >= gameState.upgrades.backpack) {
        return; 
    }

    if (activeBoss) {
        const damage = gameState.upgrades.strength * (gameState.multipliers?.strength || 1);
        const newHealth = Math.max(0, activeBoss.health - damage);
        
        if (newHealth === 0) {
            const rewardCount = Math.floor(activeBoss.difficulty * 2);
            const newResources = { ...gameState.resources };
            const newWeights = { ...gameState.resourceWeights };
            const newAchievements = Array.from(new Set([...gameState.achievements, 'boss_defeated']));
            
            newResources[activeBoss.type] = (newResources[activeBoss.type] || 0) + rewardCount;
            newWeights[activeBoss.type] = (newWeights[activeBoss.type] || 0) + (rewardCount * activeBoss.rewardMultiplier);
            
            const newState = {
                ...gameState,
                resources: newResources,
                resourceWeights: newWeights,
                achievements: newAchievements,
                totalResourcesMined: gameState.totalResourcesMined + rewardCount
            };
            setGameState(newState);
            saveGameState(newState);
            setActiveBoss(null);
            setLastMinedInfo([{ name: `Boss ${activeBoss.name}`, size: 'Gargantuan', color: activeBoss.color }]);
        } else {
            setActiveBoss({ ...activeBoss, health: newHealth });
            setLastMinedInfo([{ name: 'HIT!', size: '', color: '#ff0000' }]);
        }
        return;
    }

    const { strength, luck, multiMine } = gameState.upgrades;
    const baseStrength = strength * (gameState.multipliers?.strength || 1);
    
    // Active Multipliers from Multi-Event System
    const activeLuckMult = activeEvents.reduce((acc, e) => {
        const ev = EVENTS[e.id];
        return acc * (ev.type === 'luck' ? ev.multiplier : 1);
    }, 1);

    const isNeonEvent = activeEvents.some(e => e.id === 'neon_overload');
    const xpMult = (isNeonEvent ? 2 : 1) * (gameState.multipliers?.xp || 1);

    // Boosts
    const levelBoost = 1 + ((gameState.level || 1) - 1) * 0.005; // 0.5% per level
    const mutationLuckBoost = (gameState.mutations ?? []).reduce((acc, mId) => {
        const m = MUTATIONS.find(x => x.id === mId);
        return acc + (m?.boost.type === 'luck' ? m.boost.amount : 0);
    }, 0);

    const luckMultiplier = (luck * (1 + mutationLuckBoost)) * activeLuckMult * levelBoost * (gameState.multipliers?.luck || 1);

    // Boss Spawn Chance
    const bossRoll = Math.random();
    if (bossRoll < (0.012 * (1 + luckMultiplier * 0.08))) {
        const availableOres = Object.values(ORES)
            .filter(ore => strength >= ore.minStrength / 2);
        const selectedOre = availableOres[Math.floor(Math.random() * availableOres.length)];
        
        const difficulty = Math.max(8, Math.floor(selectedOre.minStrength * 1.5 * levelBoost));
        
        setActiveBoss({
            type: selectedOre.type,
            health: difficulty,
            maxHealth: difficulty,
            rewardMultiplier: 18 + (luck * 0.8 * (gameState.multipliers?.luck || 1)),
            name: selectedOre.name,
            color: selectedOre.color,
            difficulty: difficulty
        });
        return;
    }

    const oresToMine = Math.min(multiMine, (gameState.upgrades.backpack as number) - (totalHeld as number));
    
    const newResources = { ...gameState.resources };
    const newWeights = { ...gameState.resourceWeights };
    let totalMinedThisSession = 0;
    const minedThisTurn: {name: string, size: string, color: string}[] = [];

    for (let i = 0; i < oresToMine; i++) {
      const roll = Math.random();
      
      const availableOres = Object.values(ORES)
        .filter(ore => baseStrength >= ore.minStrength)
        .sort((a, b) => b.rarity - a.rarity);

      let selectedOre = ORES[OreType.COAL];
      for (const ore of availableOres) {
        let rarityThreshold = ore.rarity * luckMultiplier;
        if (roll <= rarityThreshold) {
          selectedOre = ore;
        }
      }

      // Determine Size
      const sizeRoll = Math.random();
      let size: OreSize = 'Small';
      if (sizeRoll < 0.05) size = 'Gigantic';
      else if (sizeRoll < 0.15) size = 'Large';
      else if (sizeRoll < 0.40) size = 'Medium';

      const weightMultiplier = ORE_SIZE_MULTIPLIERS[size];
      
      newResources[selectedOre.type] = (newResources[selectedOre.type] || 0) + 1;
      newWeights[selectedOre.type] = (newWeights[selectedOre.type] || 0) + weightMultiplier;
      totalMinedThisSession++;
      minedThisTurn.push({ name: selectedOre.name, size, color: selectedOre.color });

      // XP and Mutation Logic
      gameState.xp = (gameState.xp || 0) + (XP_PER_ORE * xpMult);

      if (activeEvents.length > 0 && Math.random() < 0.001) {
          const unlockedMutations = MUTATIONS.filter(m => !(gameState.mutations ?? []).includes(m.id));
          if (unlockedMutations.length > 0) {
              const mutation = unlockedMutations[Math.floor(Math.random() * unlockedMutations.length)];
              gameState.mutations = [...(gameState.mutations ?? []), mutation.id];
              minedThisTurn.push({ name: 'MUTATION!', size: 'Giant', color: '#a855f7' });
          }
      }
    }

    // Level calculation
    let newLevel = gameState.level || 1;
    let currentXP = gameState.xp || 0;
    const nextLevelXP = XP_BASE * Math.pow(newLevel, 1.5);

    if (currentXP >= nextLevelXP) {
        newLevel++;
        currentXP -= nextLevelXP;
        minedThisTurn.push({ name: 'LEVEL UP!', size: 'Giant', color: '#fbbf24' });
    }

    // Random Event Check (only if no events are active)
    if (activeEvents.length === 0 && Math.random() < 0.002) {
        const eventIds = Object.keys(EVENTS);
        const randomEventId = eventIds[Math.floor(Math.random() * eventIds.length)];
        triggerEvent(randomEventId);
    }

    const newState = {
      ...gameState,
      resources: newResources,
      resourceWeights: newWeights,
      totalResourcesMined: gameState.totalResourcesMined + totalMinedThisSession,
      xp: currentXP,
      level: newLevel
    };

    setLastMinedInfo(minedThisTurn);
    setGameState(newState);
    saveGameState(newState);
    checkAchievements(newState);
  };

  const triggerEvent = (eventId: string, isStackable = false) => {
    const event = EVENTS[eventId];
    if (!event) return;

    setActiveEvents(prev => {
        const existing = prev.find(e => e.id === eventId);
        if (existing && isStackable) {
            return prev.map(e => e.id === eventId ? { ...e, duration: e.duration + event.duration } : e);
        }
        return [...prev, { id: eventId, startTime: Date.now(), duration: event.duration }];
    });
  };

  // --- Event & Prestige Logic ---
  useEffect(() => {
    if (!gameState || (!user && !isGuest)) return;
    
    const interval = setInterval(() => {
        if (Date.now() >= gameState.nextEventTime) {
            const eventToTrigger = gameState.nextEventId || Object.keys(EVENTS)[0];
            triggerEvent(eventToTrigger);
            
            const evIds = Object.keys(EVENTS);
            const nextId = evIds[Math.floor(Math.random() * evIds.length)];
            const nextTime = Date.now() + 7200000; // 2 hours
            
            const newState = {
                ...gameState,
                nextEventTime: nextTime,
                nextEventId: nextId
            };
            setGameState(newState);
            saveGameState(newState);
        }
    }, 10000); // Check every 10s

    return () => clearInterval(interval);
  }, [gameState?.nextEventTime, user]);

  const buyMutation = (mutationId: string) => {
    if (!gameState) return;
    const mutation = MUTATIONS.find(m => m.id === mutationId);
    if (!mutation || gameState.money < mutation.cost || (gameState.mutations ?? []).includes(mutationId)) return;

    const newState = {
        ...gameState,
        money: gameState.money - mutation.cost,
        mutations: [...(gameState.mutations ?? []), mutationId]
    };
    setGameState(newState);
    saveGameState(newState);
  };

  const craftPrestige = (recipeId: string) => {
    if (!gameState || !user) return;
    const recipe = PRESTIGE_RECIPES.find(r => r.id === recipeId);
    if (!recipe) return;

    const canAfford = Object.entries(recipe.requirements).every(([type, amount]) => {
        const inBackpack = gameState.resources[type as OreType] || 0;
        const inVault = gameState.vaultResources?.[type as OreType] || 0;
        return (inBackpack + inVault) >= amount;
    });
    if (!canAfford) return;

    // Prestige typically resets resources; we should also clear the vault if requirements are met from it
    // or just let it reset all resources entirely as intended by the current 0 values.
    // However, we need to ensure vault resources are also reset if they are part of the "progress".
    // For now, let's just allow the requirement check to pass if sum is enough.

    const initialData: UserData = {
        ...gameState,
        money: 0,
        resources: {
          [OreType.COAL]: 0,
          [OreType.IRON]: 0,
          [OreType.GOLD]: 0,
          [OreType.SAPPHIRE]: 0,
          [OreType.RUBY]: 0,
          [OreType.EMERALD]: 0,
          [OreType.DIAMOND]: 0,
          [OreType.OBSIDIAN]: 0,
          [OreType.MYTHRIL]: 0,
          [OreType.ADAMANTITE]: 0,
          [OreType.CRYSTAL]: 0
        },
        vaultResources: {
            [OreType.COAL]: 0,
            [OreType.IRON]: 0,
            [OreType.GOLD]: 0,
            [OreType.SAPPHIRE]: 0,
            [OreType.RUBY]: 0,
            [OreType.EMERALD]: 0,
            [OreType.DIAMOND]: 0,
            [OreType.OBSIDIAN]: 0,
            [OreType.MYTHRIL]: 0,
            [OreType.ADAMANTITE]: 0,
            [OreType.CRYSTAL]: 0
        },
        upgrades: {
          strength: 1,
          luck: 1,
          backpack: 5,
          multiMine: 1
        },
        prestige: (gameState.prestige || 0) + 1,
        achievements: Array.from(new Set([...gameState.achievements, 'prestige_earned']))
    };
    
    setGameState(initialData);
    saveGameState(initialData);
  };
  
  const completeTutorial = () => {
    if (!gameState) return;
    const newState = { ...gameState, hasCompletedTutorial: true };
    setGameState(newState);
    saveGameState(newState);
  };

  const buyEvent = (eventId: string) => {
    if (!gameState) return;
    const shopItem = EVENT_SHOP.find(i => i.id === eventId);
    if (!shopItem || gameState.money < shopItem.cost) return;

    const newState = {
        ...gameState,
        money: gameState.money - shopItem.cost
    };
    setGameState(newState);
    saveGameState(newState);
    triggerEvent(eventId, true);
  };

  const vaultResource = (type: string, amount: number) => {
    if (!gameState || (gameState.resources[type] || 0) < amount || amount <= 0) return;
    const newState = {
        ...gameState,
        resources: { ...gameState.resources, [type]: gameState.resources[type] - amount },
        vaultResources: { ...(gameState.vaultResources || {}), [type]: ((gameState.vaultResources?.[type]) || 0) + amount }
    };
    setGameState(newState);
    saveGameState(newState);
  };

  const devaultResource = (type: string, amount: number) => {
    if (!gameState || (gameState.vaultResources?.[type] || 0) < amount || amount <= 0) return;
    
    // Check backpack capacity
    const currentPackSize = (Object.values(gameState.resources) as number[]).reduce((a, b) => a + b, 0);
    const availableSpace = gameState.upgrades.backpack - currentPackSize;
    const actualAmount = Math.min(amount, availableSpace);

    if (actualAmount <= 0) return;

    const newState = {
        ...gameState,
        resources: { ...gameState.resources, [type]: (gameState.resources[type] || 0) + actualAmount },
        vaultResources: { ...gameState.vaultResources, [type]: gameState.vaultResources[type] - actualAmount }
    };
    setGameState(newState);
    saveGameState(newState);
  };

  const sellResources = () => {
    if (!gameState) return;
    let earnings = 0;
    const newResources = { ...gameState.resources };
    const newWeights = { ...gameState.resourceWeights };
    
    Object.keys(newResources).forEach(key => {
      const type = key as OreType;
      let eventMultiplier = activeEvents.reduce((acc, e) => {
          const ev = EVENTS[e.id];
          return acc * (ev.type === 'gold' ? ev.multiplier : 1);
      }, 1);

      // Boosts
      const levelGoldBoost = 1 + ((gameState.level || 1) - 1) * 0.01; // 1% per level
      const mutationGoldBoost = (gameState.mutations ?? []).reduce((acc, mId) => {
          const m = MUTATIONS.find(x => x.id === mId);
          return acc + (m?.boost.type === 'gold' ? m.boost.amount : 0);
      }, 0);
      
      const count = newResources[type] || 0;
      const weightBonus = newWeights[type] || count; // Default to 1:1 if weight info missing
      const craftGoldMult = gameState.multipliers?.gold || 1;
      
      earnings += weightBonus * ORES[type].value * eventMultiplier * levelGoldBoost * (1 + mutationGoldBoost) * craftGoldMult;
      
      newResources[type] = 0;
      newWeights[type] = 0;
    });

    const newState = {
      ...gameState,
      money: gameState.money + earnings,
      resources: newResources,
      resourceWeights: newWeights
    };
    setGameState(newState);
    saveGameState(newState);
  };

  const upgrade = (type: keyof Upgrades) => {
    if (!gameState) return;
    const config = UPGRADE_CONFIGS[type];
    const currentLevel = gameState.upgrades[type];
    const cost = Math.floor(config.baseCost * Math.pow(config.multiplier, currentLevel - (type === 'backpack' ? 5 : 1)));

    if (gameState.money >= cost) {
      const inc = 'increment' in config ? (config.increment as number) : 1;
      const newState = {
        ...gameState,
        money: gameState.money - cost,
        upgrades: {
          ...gameState.upgrades,
          [type]: currentLevel + inc
        }
      };
      setGameState(newState);
      saveGameState(newState);
      checkAchievements(newState);
    }
  };

  const checkAchievements = (state: UserData) => {
    const newAchievements = [...state.achievements];
    let changed = false;
    
    ACHIEVEMENTS.forEach(ach => {
      if (!newAchievements.includes(ach.id) && ach.requirement(state)) {
        newAchievements.push(ach.id);
        changed = true;
      }
    });

    if (changed) {
      setGameState({ ...state, achievements: newAchievements });
      saveGameState({ ...state, achievements: newAchievements });
    }
  };

  const signOutUser = async () => {
    try {
      await auth.signOut();
      setUser(null);
      setGameState(null);
    } catch (error) {
      console.error("Error signing out:", error);
    }
  };

  const craftItem = (recipeId: string) => {
    if (!gameState) return;
    const recipe = CRAFTING_RECIPES.find(r => r.id === recipeId);
    if (!recipe) return;

    // Check cost from both backpack and vault
    const canAfford = Object.entries(recipe.cost).every(([type, amount]) => {
        const inBackpack = gameState.resources[type as OreType] || 0;
        const inVault = gameState.vaultResources?.[type as OreType] || 0;
        return (inBackpack + inVault) >= amount;
    });

    if (!canAfford) return alert("Not enough resources in Backpack or Machine!");

    const newResources = { ...gameState.resources };
    const newVaultResources = { ...(gameState.vaultResources || {}) };

    Object.entries(recipe.cost).forEach(([type, amount]) => {
      const oreType = type as OreType;
      const inBackpack = newResources[oreType] || 0;
      
      if (inBackpack >= amount) {
        newResources[oreType] -= amount;
      } else {
        const remaining = amount - inBackpack;
        newResources[oreType] = 0;
        newVaultResources[oreType] = (newVaultResources[oreType] || 0) - remaining;
      }
    });

    let newUpgrades = { ...gameState.upgrades };
    let newMultipliers = { ...gameState.multipliers || { gold: 1, luck: 1, xp: 1, strength: 1 } };

    const effects = recipe.effect.split(',');
    effects.forEach(eff => {
        const [effectType, effectVal] = eff.split(':');
        const val = parseFloat(effectVal);

        if (effectType === 'luck_add') newUpgrades.luck += val;
        else if (effectType === 'backpack_add') newUpgrades.backpack += val;
        else if (effectType === 'strength_mult') newMultipliers.strength *= val;
        else if (effectType === 'luck_mult') newMultipliers.luck *= val;
        else if (effectType === 'xp_mult') newMultipliers.xp *= val;
        else if (effectType === 'value_mult') newMultipliers.gold *= val;
    });

    const newState = {
      ...gameState,
      resources: newResources,
      vaultResources: newVaultResources,
      upgrades: newUpgrades,
      multipliers: newMultipliers,
      achievements: [...gameState.achievements, `crafted_${recipeId}`]
    };

    setGameState(newState);
    saveGameState(newState);
  };

  const updateProfile = async (customization: Partial<UserData['profileCustomization']>) => {
    if (!gameState || (!user && !isGuest)) return;
    const newState = {
        ...gameState,
        profileCustomization: {
            ...gameState.profileCustomization,
            ...customization
        }
    };
    setGameState(newState);
    saveGameState(newState);
  };

  const runAdminCommand = (command: string, value?: any) => {
    if (!gameState || !user || !ADMIN_EMAILS.includes(user.email || '')) return;

    let newState = { ...gameState };

    switch (command) {
        case 'add_money':
            newState.money += value || 1000000;
            break;
        case 'add_xp':
            newState.xp += value || 50000;
            break;
        case 'reset_prestige':
            newState.prestige = 0;
            break;
        case 'max_upgrades':
            newState.upgrades = {
                strength: 1000,
                luck: 1000,
                backpack: 10000,
                multiMine: 5
            };
            break;
        case 'trigger_chaos':
            const evIds = Object.keys(EVENTS);
            const randomId = evIds[Math.floor(Math.random() * evIds.length)];
            newState.activeEvents = [{
                id: randomId,
                startTime: Date.now(),
                duration: 3600000 // 1 hour
            }];
            break;
        case 'add_ores':
            Object.keys(ORES).forEach(type => {
                newState.resources[type as OreType] = (newState.resources[type as OreType] || 0) + 1000;
            });
            break;
    }

    setGameState(newState);
    saveGameState(newState);
  };

  if (loading || ((user || isGuest) && !gameState)) {
    return (
      <div className="flex items-center justify-center h-screen bg-[#050505] text-white">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        >
          <RotateCcw className="w-12 h-12 text-blue-500" />
        </motion.div>
      </div>
    );
  }

  if ((!user && !isGuest) || !gameState) {
    return (
      <div className="h-screen flex items-center justify-center bg-black bg-nebula p-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center p-12 rounded-[50px] bg-black/40 backdrop-blur-3xl border border-white/10 shadow-2xl"
        >
          <div className="bg-blue-600/20 p-6 rounded-3xl mb-8 inline-block relative">
            <div className="absolute inset-0 bg-blue-500 blur-3xl opacity-20"></div>
            <Pickaxe className="w-16 h-16 text-blue-400 relative z-10" />
          </div>
          <h1 className="text-6xl font-black mb-4 tracking-[0.1em] text-white italic drop-shadow-[0_0_15px_rgba(59,130,246,0.5)]">CRYSTAL DEEP</h1>
          <p className="text-blue-200/60 mb-10 max-w-sm mx-auto uppercase text-[10px] font-bold tracking-[0.4em]">Subterranean Extraction Simulator</p>
          
          <div className="flex flex-col gap-4">
            <button 
                onClick={login}
                className="w-full bg-white text-black px-10 py-5 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:scale-105 active:scale-95 transition-all shadow-xl shadow-white/5"
            >
                Login with Google <ArrowRight className="w-5 h-5" />
            </button>
            <button 
                onClick={enterAsGuest}
                className="w-full bg-blue-600/10 text-blue-400 border border-blue-500/20 px-10 py-5 rounded-2xl font-black uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-blue-600/20 transition-all"
            >
                Play as Guest
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-black/40 text-white flex flex-col font-sans overflow-hidden bg-cave-mesh">
      {/* Header Stat Bar */}
      <header className="px-6 py-4 border-b border-white/5 flex flex-col gap-4 bg-white/[0.02] backdrop-blur-2xl sticky top-0 z-50">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-400" />
                    <span className="text-xl font-mono font-bold text-green-400">${gameState?.money.toLocaleString()}</span>
                </div>
                <div className="flex flex-col">
                    <div className="flex items-center justify-between text-[8px] font-black uppercase tracking-[0.2em] text-blue-300/50 mb-1">
                        <span>Level {gameState.level || 1}</span>
                        <span>{Math.floor(((gameState.xp || 0) / (XP_BASE * Math.pow(gameState.level || 1, 1.5))) * 100)}%</span>
                    </div>
                    <div className="w-32 h-1.5 bg-white/5 rounded-full overflow-hidden ring-1 ring-white/5">
                        <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${((gameState.xp || 0) / (XP_BASE * Math.pow(gameState.level || 1, 1.5))) * 100}%` }}
                            className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.8)]"
                        />
                    </div>
                </div>
            </div>

            <div className="flex items-center gap-2">
               <div className="text-right flex flex-col items-end mr-2">
                   <span className="text-[10px] font-black text-white leading-none">{isGuest ? "Guest Miner" : user?.displayName}</span>
                   <span className="text-[8px] uppercase tracking-widest text-blue-400/60 font-bold">{(gameState.profileCustomization?.title || 'Miner')} {isGuest && "(Guest)"}</span>
               </div>
               <div className="bg-black/60 p-1 rounded-lg border border-white/10 shadow-lg">
                   <AvatarDisplay 
                       icon={gameState.profileCustomization?.avatarIcon} 
                       color={gameState.profileCustomization?.avatarColor} 
                       className="w-6 h-6"
                   />
               </div>
            </div>
        </div>

        <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide pb-1">
            <div className="flex items-center gap-1.5 bg-blue-600/10 px-3 py-1.5 rounded-xl border border-blue-500/20 shadow-lg shrink-0">
                <Backpack className="w-3.5 h-3.5 text-blue-400" />
                <span className="text-[10px] font-bold text-blue-200">
                    {(Object.values(gameState?.resources || {}) as number[]).reduce((a, b) => a + b, 0)} / {gameState?.upgrades.backpack}
                </span>
            </div>

            {/* Next Event Timer */}
            <div className="flex flex-col bg-white/5 px-3 py-1.5 rounded-xl border border-white/10 shrink-0">
                <div className="flex items-center gap-1.5">
                    <Zap className="w-3 h-3 text-yellow-500" />
                    <span className="text-[8px] font-black uppercase tracking-widest text-yellow-500">Next: {EVENTS[gameState.nextEventId]?.name}</span>
                </div>
                <span className="text-[10px] font-mono font-bold text-gray-400">
                    {nextEventCountdown}
                </span>
            </div>

            {activeEvents.map(event => (
                <div key={event.id} className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10 shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ backgroundColor: EVENTS[event.id].color }}></div>
                    <span className="text-[8px] font-black uppercase tracking-widest text-gray-300">
                        {EVENTS[event.id].name} ({Math.ceil((event.duration - (Date.now() - event.startTime) / 1000))}s)
                    </span>
                </div>
            ))}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-24 relative">
        <AnimatePresence mode="wait">
          {activeTab === 'mining' && (
            <MiningView 
              gameState={gameState!} 
              lastMined={lastMinedInfo}
              activeBoss={activeBoss}
              onMine={mineOre} 
              onSkipBoss={skipBoss}
            />
          )}
          {activeTab === 'shop' && (
            <ShopView 
              gameState={gameState!} 
              onUpgrade={upgrade} 
              onSell={sellResources}
            />
          )}
          {activeTab === 'crafting' && (
             <CraftingView 
               gameState={gameState!} 
               onCraft={craftItem} 
               onPrestige={craftPrestige}
             />
          )}
          {activeTab === 'leaderboard' && (
            <LeaderboardView 
                leaderboard={leaderboard} 
                category={leaderboardCategory}
                onSetCategory={setLeaderboardCategory}
                isGuest={isGuest}
            />
          )}
          {activeTab === 'profile' && (
            <ProfileView 
                gameState={gameState!} 
                playtime={playtimeSeconds}
                onUpdateProfile={updateProfile}
                isGuest={isGuest}
                isAdmin={user && user.email ? ADMIN_EMAILS.includes(user.email) : false}
                onAdminCommand={runAdminCommand}
                onLogout={async () => {
                    await auth.signOut();
                    setIsGuest(false);
                    setGameState(null);
                    window.location.reload();
                }}
                onExitGuest={() => {
                    setIsGuest(false);
                    setGameState(null);
                    window.location.reload();
                }}
            />
          )}
          {activeTab === 'inventory' && (
            <InventoryView 
                gameState={gameState!}
                onVault={vaultResource}
                onDevault={devaultResource}
            />
          )}
          {activeTab === 'events' && (
            <EventShopView 
                gameState={gameState!}
                activeEvents={activeEvents}
                onBuyEvent={buyEvent}
                onBuyMutation={buyMutation}
            />
          )}
          {activeTab === 'ai' && (
            <AIView gameState={gameState!} />
          )}
        </AnimatePresence>
      </main>

      {/* Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-black/90 backdrop-blur-3xl border-t border-white/10 px-2 py-4 flex items-center justify-around z-50 rounded-t-[32px] shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
        <NavButton active={activeTab === 'mining'} onClick={() => setActiveTab('mining')} icon={<Pickaxe className="w-5 h-5" />} label="Mine" />
        <NavButton active={activeTab === 'shop'} onClick={() => setActiveTab('shop')} icon={<Store className="w-5 h-5" />} label="Shop" />
        <NavButton active={activeTab === 'crafting'} onClick={() => setActiveTab('crafting')} icon={<Hammer className="w-5 h-5" />} label="Craft" />
        <NavButton active={activeTab === 'inventory'} onClick={() => setActiveTab('inventory')} icon={<Archive className="w-5 h-5" />} label="Machine" />
        <NavButton active={activeTab === 'events'} onClick={() => setActiveTab('events')} icon={<Zap className="w-5 h-5" />} label="Chaos" />
        <NavButton active={activeTab === 'leaderboard'} onClick={() => setActiveTab('leaderboard')} icon={<Trophy className="w-5 h-5" />} label="Ranks" />
        <NavButton active={activeTab === 'profile'} onClick={() => setActiveTab('profile')} icon={<TrendingUp className="w-5 h-5" />} label="Stats" />
        <button 
          onClick={() => setShowRestartModal(true)}
          className="p-2 text-gray-800 hover:text-red-500 transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </nav>

      {/* Restart Modal */}
      {showRestartModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#111] border border-red-900/50 p-8 rounded-3xl max-w-sm w-full">
            <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
              <AlertTriangle className="text-red-500" /> WIPE SERVER?
            </h2>
            <p className="text-gray-400 mb-6 font-mono text-sm">Typing 'RESTART' will reset all progress, resources, and upgrades. This cannot be undone.</p>
            <input 
              type="text" 
              value={restartInput}
              onChange={(e) => setRestartInput(e.target.value)}
              placeholder="Type RESTART"
              className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 mb-6 focus:border-red-500 outline-none"
            />
            <div className="flex gap-4">
              <button onClick={() => setShowRestartModal(false)} className="flex-1 py-3 font-bold text-gray-500">Cancel</button>
              <button 
                onClick={restartTycoon}
                disabled={restartInput !== 'RESTART'}
                className="flex-1 py-3 bg-red-600 rounded-xl font-bold disabled:opacity-50"
              >
                Reset Progress
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tutorial Overlay */}
      <AnimatePresence>
        {gameState && !gameState.hasCompletedTutorial && (
          <TutorialOverlay 
            step={tutorialStep} 
            setStep={setTutorialStep} 
            onComplete={completeTutorial} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function TutorialOverlay({ step, setStep, onComplete }: { step: number, setStep: (s: number) => void, onComplete: () => void }) {
  const steps = [
    {
      title: "Welcome to Crystal Deep",
      content: "You are the latest recruit in our deep-earth extraction division. Your goal is simple: Mine, Sell, Upgrade, Transcend.",
      icon: <Pickaxe className="w-12 h-12 text-blue-400" />
    },
    {
      title: "Mining 101",
      content: "Tap the mine to extract ores. Rarer ores are deeper down. Keep an eye on your backpack capacity!",
      icon: <Backpack className="w-12 h-12 text-blue-400" />
    },
    {
        title: "The Marketplace",
        content: "Visit the Shop to sell your hauls. Use the profit to upgrade your Strength, Luck, and Backpack.",
        icon: <Store className="w-12 h-12 text-green-400" />
    },
    {
        title: "Crafting Machine",
        content: "Add rare ores to the Machine to use them for Crafting powerful items and Prestige resets.",
        icon: <Archive className="w-12 h-12 text-purple-400" />
    },
    {
        title: "Multi-Event Chaos",
        content: "Global events happen every 2 hours. They stack! Watch the timer in your header to know what's coming next.",
        icon: <Zap className="w-12 h-12 text-yellow-400" />
    }
  ];

  const current = steps[step];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-black/80 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="bg-[#0a0a0a] border border-white/10 p-10 rounded-[40px] max-w-md w-full text-center relative overflow-hidden"
      >
        <div className="absolute top-0 left-0 w-full h-1 bg-white/5">
            <motion.div 
                className="h-full bg-blue-500" 
                animate={{ width: `${((step + 1) / steps.length) * 100}%` }}
                transition={{ duration: 0.5 }}
            />
        </div>

        <button 
            onClick={onComplete}
            className="absolute top-6 right-6 text-[10px] font-black uppercase tracking-widest text-gray-600 hover:text-white transition-colors"
        >
            Skip Tutorial
        </button>

        <div className="mb-8 flex justify-center">
            <div className="p-6 bg-white/5 rounded-3xl relative">
                <div className="absolute inset-0 bg-blue-500/20 blur-2xl rounded-full"></div>
                <div className="relative z-10">{current.icon}</div>
            </div>
        </div>

        <h2 className="text-3xl font-black mb-4 tracking-tight">{current.title}</h2>
        <p className="text-gray-400 text-sm mb-10 leading-relaxed">{current.content}</p>

        <div className="flex gap-4">
            {step > 0 && (
                <button 
                    onClick={() => setStep(step - 1)}
                    className="flex-1 py-4 rounded-2xl border border-white/10 font-bold uppercase tracking-widest text-xs hover:bg-white/5 transition-all"
                >
                    Back
                </button>
            )}
            <button 
                onClick={() => step === steps.length - 1 ? onComplete() : setStep(step + 1)}
                className="flex-[2] py-4 rounded-2xl bg-white text-black font-black uppercase tracking-widest text-xs hover:scale-105 active:scale-95 transition-all shadow-xl shadow-white/10"
            >
                {step === steps.length - 1 ? "Let's Dig!" : "Next Tip"}
            </button>
        </div>
      </motion.div>
    </motion.div>
  );
}

// --- Sub-Views ---

function AvatarDisplay({ icon, color, className = "w-8 h-8" }: { icon?: string, color?: string, className?: string }) {
    const props = { className, style: { color } };
    switch (icon) {
        case 'cat': return <Cat {...props} />;
        case 'dog': return <Dog {...props} />;
        case 'bot': return <Bot {...props} />;
        case 'ghost': return <Ghost {...props} />;
        case 'crown': return <Crown {...props} />;
        case 'flame': return <Flame {...props} />;
        case 'star': return <Star {...props} />;
        default: return <Pickaxe {...props} />;
    }
}

function NavButton({ active, icon, label, onClick }: { active: boolean, icon: any, label: string, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-all ${active ? 'text-blue-500 scale-110' : 'text-gray-500'}`}
    >
      {icon}
      <span className="text-[10px] uppercase font-bold tracking-widest">{label}</span>
    </button>
  );
}

function MiningView({ gameState, lastMined, activeBoss, onMine, onSkipBoss }: { gameState: UserData, lastMined: {name: string, size: string, color: string}[], activeBoss: BossOre | null, onMine: (x: number, y: number) => void, onSkipBoss: () => void }) {
    const [clicks, setClicks] = useState<{id: number, x: number, y: number, info?: {name: string, size: string, color: string}}[]>([]);
    const [isBackpackFull, setIsBackpackFull] = useState(false);

    const totalHeld = (Object.values(gameState.resources) as number[]).reduce((a, b) => a + b, 0);
    const backpackCapacity = gameState.upgrades.backpack;

    useEffect(() => {
        if (totalHeld >= backpackCapacity) {
            setIsBackpackFull(true);
        } else {
            setIsBackpackFull(false);
        }
    }, [totalHeld, backpackCapacity]);

    // We use a useEffect to handle the floating text synchronization
    useEffect(() => {
        if (lastMined.length > 0) {
            // This is a bit tricky because one click can mine multiple ores.
            // For simplicity, we'll just associate the last mined info with the most recent click.
            setClicks(prev => {
                const updated = [...prev];
                if (updated.length > 0) {
                    const lastClick = updated[updated.length - 1];
                    // If the last click doesn't have info yet, give it the last mined ones
                    if (!lastClick.info) {
                        return updated.map((c, i) => i === updated.length - 1 ? { ...c, info: lastMined[0] } : c);
                    }
                }
                // Fallback: create a dummy click at center if needed, but click usually exists
                return prev;
            });
        }
    }, [lastMined]);

    // Improved click handler
    const handleClick = (e: React.MouseEvent) => {
        const id = Date.now();
        const x = e.clientX;
        const y = e.clientY;
        setClicks(prev => [...prev, { id, x, y }]);
        setTimeout(() => setClicks(prev => prev.filter(c => c.id !== id)), 1500);
        onMine(x, y);
    };

    return (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="min-h-full flex flex-col p-6"
        >
            <div className="flex-1 flex flex-col items-center justify-center relative overflow-hidden">
                {/* Floating particle effect for mining */}
                <AnimatePresence>
                    {clicks.map(c => (
                        <motion.div
                          key={c.id}
                          initial={{ opacity: 1, scale: 0.5, y: c.y }}
                          animate={{ opacity: 0, scale: 1.2, y: c.y - 120, x: c.x + (Math.random() * 40 - 20) }}
                          exit={{ opacity: 0 }}
                          style={{ position: 'fixed', left: c.x, top: c.y, pointerEvents: 'none' }}
                          className="flex flex-col items-center z-20"
                        >
                            <span className="text-white font-bold text-sm drop-shadow-md">
                                {c.info ? `${c.info.size} ${c.info.name}` : '+MINE'}
                            </span>
                            {c.info && gameState.mutations.length > 0 && (
                                <span className="text-[8px] text-purple-400 font-black uppercase tracking-widest animate-pulse">
                                    {MUTATIONS.find(m => m.id === gameState.mutations[0])?.name}
                                </span>
                            )}
                            {c.info && (
                                <div 
                                    className="w-3 h-3 rounded-full mt-1" 
                                    style={{ backgroundColor: c.info.color }}
                                />
                            )}
                        </motion.div>
                    ))}
                </AnimatePresence>

                <motion.button
                  whileTap={{ scale: 0.9, rotate: -10 }}
                  onClick={handleClick}
                  animate={isBackpackFull ? { x: [0, -10, 10, -10, 10, 0] } : {}}
                  className={`relative group focus:outline-none ${isBackpackFull ? 'opacity-50' : ''}`}
                >
                    <div className={`absolute inset-0 blur-[80px] rounded-full group-active:scale-150 transition-all ${activeBoss ? 'bg-red-500/40' : 'bg-blue-400/30'}`}></div>
                    
                    {activeBoss ? (
                        <div className="bg-white/[0.05] backdrop-blur-2xl p-20 rounded-[50px] border-4 border-red-500/30 relative z-10 shadow-[0_0_50px_rgba(239,68,68,0.2)] flex flex-col items-center group">
                            <motion.div
                                animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.8, 0.4] }}
                                transition={{ repeat: Infinity, duration: 2 }}
                                className="w-56 h-56 rounded-full blur-3xl absolute"
                                style={{ backgroundColor: activeBoss.color }}
                            ></motion.div>
                            <Sparkles className="w-32 h-32 relative z-10 drop-shadow-[0_0_15px_rgba(255,255,255,0.5)]" style={{ color: activeBoss.color }} />
                            <div className="mt-4 w-full bg-gray-800 rounded-full h-2 overflow-hidden border border-white/10">
                                <motion.div 
                                    className="bg-red-500 h-full"
                                    initial={{ width: '100%' }}
                                    animate={{ width: `${(activeBoss.health / activeBoss.maxHealth) * 100}%` }}
                                ></motion.div>
                            </div>
                            <span className="text-[10px] font-bold mt-2 uppercase text-gray-500">Boss Ore HP: {activeBoss.health}</span>
                        </div>
                    ) : (
                        <div className="bg-white/[0.05] backdrop-blur-3xl p-16 rounded-full border-4 border-white/10 relative z-10 shadow-[0_0_40px_rgba(59,130,246,0.15)] group-hover:shadow-[0_0_60px_rgba(59,130,246,0.3)] transition-all">
                             <Pickaxe className={`w-32 h-32 text-white group-hover:rotate-12 transition-transform drop-shadow-[0_0_10px_rgba(255,255,255,0.3)] ${isBackpackFull ? 'text-red-500' : ''}`} />
                        </div>
                    )}
                </motion.button>

                {isBackpackFull && (
                    <motion.div 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="absolute bottom-10 bg-red-600 text-white px-6 py-2 rounded-full font-bold text-xs uppercase tracking-widest animate-bounce z-30"
                    >
                        Backpack Overloaded!
                    </motion.div>
                )}

                {activeBoss && (
                    <button 
                        onClick={onSkipBoss}
                        className="mt-8 text-xs font-bold text-gray-600 uppercase tracking-widest hover:text-white transition-colors"
                    >
                        [ Skip Boss ]
                    </button>
                )}


                {/* Visual indicators of resources held */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none">
                    <div className="flex gap-1 -translate-y-40">
                        {Object.entries(gameState?.resources || {}).map(([type, count]) => (count as number) > 0 && (
                            <div key={type} className="w-1.5 h-6 rounded-full" style={{ backgroundColor: ORES[type as OreType].color }}></div>
                        ))}
                    </div>
                </div>
                
                <p className="mt-12 text-sm uppercase tracking-[0.3em] font-bold text-gray-500">Tap to extract resources</p>
            </div>

            <div className="mt-8 w-full block">
                <div className="bg-white/5 border border-white/10 p-8 rounded-3xl flex flex-col items-center justify-center">
                    <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-1">Mined Today</span>
                    <span className="text-3xl font-mono tracking-tighter">{gameState.totalResourcesMined.toLocaleString()}</span>
                </div>
            </div>
        </motion.div>
    );
}

function ShopView({ gameState, onUpgrade, onSell }: { gameState: UserData, onUpgrade: (type: keyof Upgrades) => void, onSell: () => void }) {
  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="p-6"
    >
      <h2 className="text-4xl font-bold mb-8 tracking-tighter">Black Market</h2>
      
      <div className="mb-8">
          <button 
           onClick={onSell}
           className="w-full bg-green-600 text-white p-8 rounded-[40px] font-bold flex items-center justify-between hover:bg-green-500 transition-all shadow-xl shadow-green-900/20 group"
          >
              <div className="flex items-center gap-4">
                  <div className="bg-white/20 p-3 rounded-2xl group-hover:scale-110 transition-transform">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <div className="text-left">
                      <span className="block text-xs uppercase tracking-widest opacity-70">Liquidate Assets</span>
                      <span className="text-2xl font-mono leading-tight">Sell Inventory</span>
                  </div>
              </div>
              <ArrowRight className="w-6 h-6 opacity-50 group-hover:translate-x-2 transition-transform" />
          </button>
      </div>

      <div className="grid gap-4">
        {Object.entries(UPGRADE_CONFIGS).map(([key, config]) => {
          const type = key as keyof Upgrades;
          const currentLevel = gameState.upgrades[type];
          const cost = Math.floor(config.baseCost * Math.pow(config.multiplier, currentLevel - (type === 'backpack' ? 5 : 1)));
          const canAfford = gameState.money >= cost;

          return (
            <button
               key={key}
               onClick={() => onUpgrade(type)}
               disabled={!canAfford}
               className={`p-6 rounded-3xl border flex items-center justify-between transition-all ${
                 canAfford 
                 ? 'bg-white/5 border-white/10 hover:border-blue-500/50' 
                 : 'bg-white/2 border-white/5 opacity-50'
               }`}
            >
              <div className="text-left">
                <h3 className="font-bold text-lg">{config.name}</h3>
                <p className="text-xs text-gray-500 max-w-[200px]">{config.description}</p>
                <div className="mt-2 flex items-center gap-2">
                    <span className="bg-blue-600/20 text-blue-500 text-[10px] px-2 py-0.5 rounded font-bold uppercase">LVL {type === 'backpack' ? (currentLevel-5)/5 + 1 : currentLevel}</span>
                </div>
              </div>
              <div className="text-right">
                <span className={`text-xl font-mono font-bold ${canAfford ? 'text-green-400' : 'text-red-500'}`}>
                  ${cost.toLocaleString()}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </motion.div>
  );
}

function CraftingView({ gameState, onCraft, onPrestige }: { gameState: UserData, onCraft: (id: string) => void, onPrestige: (id: string) => void }) {
    return (
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="p-6 pb-24"
        >
          <h2 className="text-4xl font-bold mb-4 tracking-tighter">Forge</h2>
          <p className="text-gray-400 mb-8 font-mono text-sm italic">// Use resources to unlock special traits</p>
          
          <div className="grid gap-4">
            {CRAFTING_RECIPES.map(recipe => {
                const canAfford = Object.entries(recipe.cost).every(([type, amount]) => {
                    const total = (gameState.resources[type as OreType] || 0) + (gameState.vaultResources?.[type as OreType] || 0);
                    return total >= amount;
                });
                const isAlreadyCrafted = gameState.achievements.includes(`crafted_${recipe.id}`);

                return (
                    <div key={recipe.id} className={`p-6 rounded-[32px] border ${isAlreadyCrafted ? 'bg-green-500/10 border-green-500/20' : 'bg-white/5 border-white/10'}`}>
                        <div className="flex justify-between items-start mb-4">
                            <div>
                                <h3 className="font-bold text-lg">{recipe.name}</h3>
                                <p className="text-xs text-gray-500">{recipe.description}</p>
                            </div>
                            {isAlreadyCrafted && <Sparkles className="text-green-500 w-5 h-5" />}
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mb-6">
                            {Object.entries(recipe.cost).map(([type, amount]) => (
                                <div key={type} className="flex items-center gap-1.5 bg-black/40 px-2 py-1 rounded-md border border-white/5">
                                    <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: ORES[type as OreType].color }}></div>
                                    <span className="text-[10px] font-mono">{amount} {type}</span>
                                </div>
                            ))}
                        </div>

                        <button 
                          disabled={!canAfford || isAlreadyCrafted}
                          onClick={() => onCraft(recipe.id)}
                          className={`w-full py-3 rounded-xl font-bold text-xs uppercase tracking-widest transition-all ${
                            isAlreadyCrafted 
                            ? 'bg-green-600/20 text-green-500 cursor-default' 
                            : canAfford ? 'bg-white text-black hover:bg-gray-200' : 'bg-white/5 text-gray-600'
                          }`}
                        >
                            {isAlreadyCrafted ? 'Already Forged' : canAfford ? 'Forge Item' : 'Missing Resources'}
                        </button>
                    </div>
                );
            })}

            <h3 className="text-xs font-black uppercase tracking-[0.3em] text-red-500 mt-12 mb-6">Transcendence (Prestige)</h3>
            {PRESTIGE_RECIPES.map(recipe => {
                const canAfford = Object.entries(recipe.requirements).every(([type, amount]) => {
                    const total = (gameState.resources[type as OreType] || 0) + (gameState.vaultResources?.[type as OreType] || 0);
                    return total >= amount;
                });
                return (
                    <div key={recipe.id} className="p-8 rounded-[40px] bg-red-950/20 border border-red-500/20">
                        <h3 className="text-2xl font-black mb-2 text-red-400">{recipe.name}</h3>
                        <p className="text-gray-500 text-xs mb-6">{recipe.description}</p>
                        <div className="flex flex-wrap gap-2 mb-8">
                            {Object.entries(recipe.requirements).map(([type, amount]) => {
                                const total = (gameState.resources[type as OreType] || 0) + (gameState.vaultResources?.[type as OreType] || 0);
                                const hasEnough = total >= amount;
                                return (
                                    <div key={type} className={`px-3 py-1.5 rounded-xl border flex items-center gap-2 ${hasEnough ? 'bg-red-500/10 border-red-500/40 text-red-100' : 'bg-black/40 border-white/5 text-gray-600'}`}>
                                        <div className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: ORES[type as OreType].color }}></div>
                                        <span className="text-[10px] font-mono">{total} / {amount}</span>
                                    </div>
                                );
                            })}
                        </div>
                        <button 
                            onClick={() => onPrestige(recipe.id)}
                            disabled={!canAfford}
                            className={`w-full py-5 rounded-2x font-black uppercase tracking-widest text-xs transition-all ${canAfford ? 'bg-red-600 text-white shadow-xl shadow-red-900/40 hover:scale-105' : 'bg-white/5 text-gray-700 cursor-not-allowed'}`}
                        >
                            PRESTIGE NOW
                        </button>
                    </div>
                );
            })}
            
            <InventorySummary gameState={gameState} />
          </div>
        </motion.div>
    );
}

function InventorySummary({ gameState }: { gameState: UserData }) {
    return (
        <div className="bg-black border border-white/10 p-6 rounded-3xl mt-8">
            <h4 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-4">Stockpile</h4>
            <div className="grid grid-cols-3 gap-3">
                {Object.entries(gameState?.resources || {}).map(([type, count]) => (
                    <div key={type} className="bg-white/5 p-3 rounded-xl flex flex-col items-center border border-white/5">
                        <div className="w-2 h-2 rounded-full mb-2" style={{ backgroundColor: ORES[type as OreType].color }}></div>
                        <span className="text-lg font-mono">{count as number}</span>
                        <span className="text-[10px] text-gray-600 uppercase font-bold">{type}</span>
                    </div>
                ))}
            </div>
        </div>
    )
}

function LeaderboardView({ leaderboard, category, onSetCategory, isGuest }: { leaderboard: any[], category: 'wealth' | 'mined' | 'playtime' | 'level', onSetCategory: (c: 'wealth' | 'mined' | 'playtime' | 'level') => void, isGuest: boolean }) {
  if (isGuest) {
    return (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-6 pb-24 text-center">
             <div className="bg-white/5 border border-white/10 rounded-[40px] p-12 mt-12 backdrop-blur-md">
                <div className="bg-yellow-500/10 p-6 rounded-3xl mb-8 inline-block">
                    <Trophy className="w-16 h-16 text-yellow-500" />
                </div>
                <h2 className="text-3xl font-black mb-4 tracking-tighter">Ranking Restricted</h2>
                <p className="text-gray-400 mb-8 max-w-xs mx-auto">Leaderboard access is restricted to verified extraction units. Sign in to compete globally!</p>
                <div className="flex justify-center">
                    <div className="flex items-center gap-2 text-yellow-500/60 font-black uppercase tracking-widest text-[10px]">
                         <LockIcon className="w-3 h-3" /> System Access Required
                    </div>
                </div>
            </div>
        </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="p-6 pb-24"
    >
      <h2 className="text-4xl font-bold mb-6 tracking-tighter">Hall of Fame</h2>
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2 scrollbar-hide">
        <CategoryTab active={category === 'wealth'} label="Wealth" onClick={() => onSetCategory('wealth')} />
        <CategoryTab active={category === 'mined'} label="Resources" onClick={() => onSetCategory('mined')} />
        <CategoryTab active={category === 'level'} label="Level" onClick={() => onSetCategory('level')} />
        <CategoryTab active={category === 'playtime'} label="Loyalty" onClick={() => onSetCategory('playtime')} />
      </div>

      <div className="space-y-3">
        {leaderboard.map((player, i) => (
          <div 
            key={player.uid} 
            className={`flex items-center justify-between p-5 rounded-3xl border transition-all ${
              i === 0 ? 'bg-yellow-500/10 border-yellow-500/30' : 
              i === 1 ? 'bg-gray-400/10 border-gray-400/30' :
              i === 2 ? 'bg-orange-600/10 border-orange-600/30' :
              'bg-white/2 border-white/5'
            }`}
          >
            <div className="flex items-center gap-4">
              <span className={`w-6 text-center font-mono font-bold ${i < 3 ? 'text-blue-500' : 'text-gray-700'}`}>{i + 1}</span>
              <div className="bg-black/60 p-2 rounded-xl border border-white/10 shadow-[0_0_15px_rgba(255,255,255,0.1)]">
                <AvatarDisplay 
                    icon={player.profileCustomization?.avatarIcon} 
                    color={player.profileCustomization?.avatarColor} 
                    className="w-6 h-6"
                />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-gray-200">{player.displayName}</span>
                <span className="text-[10px] text-gray-600 uppercase font-bold tracking-tight">{(player.profileCustomization?.title || 'Miner').toUpperCase()}</span>
              </div>
            </div>
            <div className="text-right">
              <span className="font-mono text-blue-400 font-bold">
                  {category === 'wealth' ? `$${player.money.toLocaleString()}` :
                   category === 'mined' ? `${player.totalResourcesMined.toLocaleString()} ores` :
                   category === 'level' ? `Level ${player.level || 1}` :
                   `${Math.floor(player.playtime / 3600)}h ${Math.floor((player.playtime % 3600) / 60)}m`}
              </span>
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function CategoryTab({ active, label, onClick }: { active: boolean, label: string, onClick: () => void }) {
    return (
        <button 
            onClick={onClick}
            className={`px-6 py-2 rounded-full font-bold text-[10px] uppercase tracking-widest transition-all whitespace-nowrap ${active ? 'bg-blue-600 text-white shadow-lg' : 'bg-white/5 text-gray-500 hover:bg-white/10'}`}
        >
            {label}
        </button>
    );
}

function ProfileView({ gameState, playtime, onUpdateProfile, isGuest, onLogout, onExitGuest, isAdmin, onAdminCommand }: { gameState: UserData, playtime: number, onUpdateProfile: (c: any) => void, isGuest: boolean, onLogout: () => Promise<void>, onExitGuest: () => void, isAdmin?: boolean, onAdminCommand?: (cmd: string, val?: any) => void }) {
    const hours = Math.floor(playtime / 3600);
    const mins = Math.floor((playtime % 3600) / 60);

    const colors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#6b7280'];

    return (
        <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="p-6 pb-24"
        >
            {isAdmin && (
                <div className="bg-red-500/10 border border-red-500/20 p-6 rounded-[32px] mb-8">
                    <div className="flex items-center gap-3 mb-6">
                        <div className="p-2 bg-red-500/20 rounded-xl">
                            <Bot className="w-5 h-5 text-red-400" />
                        </div>
                        <h3 className="text-sm font-black uppercase tracking-widest text-red-400">Admin Sector</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        <button onClick={() => onAdminCommand?.('add_money')} className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 p-3 rounded-2xl text-[10px] font-bold uppercase tracking-tighter transition-all">Add $1M</button>
                        <button onClick={() => onAdminCommand?.('add_xp')} className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 p-3 rounded-2xl text-[10px] font-bold uppercase tracking-tighter transition-all">Add 50K XP</button>
                        <button onClick={() => onAdminCommand?.('trigger_chaos')} className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 p-3 rounded-2xl text-[10px] font-bold uppercase tracking-tighter transition-all">Trigger Chaos</button>
                        <button onClick={() => onAdminCommand?.('add_ores')} className="bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 p-3 rounded-2xl text-[10px] font-bold uppercase tracking-tighter transition-all">Full Vault</button>
                    </div>
                </div>
            )}
            {isGuest && (
                <div className="bg-blue-500/10 border border-blue-500/20 p-4 rounded-3xl mb-8 flex items-center gap-4">
                    <div className="p-2 bg-blue-500/20 rounded-full">
                        <LockIcon className="w-4 h-4 text-blue-400" />
                    </div>
                    <div>
                        <p className="text-[10px] font-black uppercase tracking-widest text-blue-200">Guest Session Active</p>
                        <p className="text-[8px] text-blue-300/60 font-bold">Progress is NOT saved. Sign in to secure your extraction data.</p>
                    </div>
                </div>
            )}
            <div className="bg-white/[0.04] backdrop-blur-3xl p-8 rounded-[40px] border border-white/10 mb-8 flex flex-col items-center shadow-2xl relative overflow-hidden group">
                <div className="absolute inset-0 bg-nebula opacity-30 group-hover:opacity-50 transition-opacity"></div>
                <div className="w-24 h-24 rounded-full mb-6 relative z-10">
                    <div className="absolute inset-0 rounded-full blur-2xl opacity-60" style={{ backgroundColor: gameState.profileCustomization.avatarColor }}></div>
                    <div className="w-full h-full rounded-full border-4 border-white/10 relative z-10 flex items-center justify-center overflow-hidden bg-black/60 shadow-inner">
                        <AvatarDisplay 
                            icon={gameState.profileCustomization.avatarIcon} 
                            color={gameState.profileCustomization.avatarColor}
                            className="w-12 h-12 drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]"
                        />
                    </div>
                </div>
                <h2 className="text-3xl font-black tracking-tighter mb-1 relative z-10 text-white drop-shadow-md">{gameState.displayName}</h2>
                <span className="text-blue-400 font-black uppercase tracking-[0.4em] text-[10px] mb-8 relative z-10 drop-shadow-sm">{gameState.profileCustomization.title || 'Novice'}</span>
                
                <div className="grid grid-cols-4 gap-2 w-full relative z-10">
                    <div className="bg-white/[0.05] backdrop-blur-md h-20 rounded-3xl flex flex-col items-center justify-center border border-white/10 shadow-lg px-2">
                        <span className="text-[7px] text-blue-200/50 uppercase font-black tracking-widest mb-1">Time</span>
                        <span className="text-[10px] font-mono font-black text-white">{hours}h {mins}m</span>
                    </div>
                    <div className="bg-white/[0.05] backdrop-blur-md h-20 rounded-3xl flex flex-col items-center justify-center border border-white/10 shadow-lg px-2">
                        <span className="text-[7px] text-blue-200/50 uppercase font-black tracking-widest mb-1">Ores</span>
                        <span className="text-[10px] font-mono font-black text-white">{gameState.totalResourcesMined.toLocaleString()}</span>
                    </div>
                    <div className="bg-white/[0.05] backdrop-blur-md h-20 rounded-3xl flex flex-col items-center justify-center border border-white/10 shadow-lg px-2">
                        <span className="text-[7px] text-blue-200/50 uppercase font-black tracking-widest mb-1">Rank</span>
                        <span className="text-[10px] font-mono font-black text-white">Lvl {gameState.level || 1}</span>
                    </div>
                    <div className="bg-white/[0.05] backdrop-blur-md h-20 rounded-3xl flex flex-col items-center justify-center border border-red-500/20 shadow-lg px-2">
                        <span className="text-[7px] text-red-400/50 uppercase font-black tracking-widest mb-1">Tier</span>
                        <span className="text-[10px] font-mono font-black text-red-400">{gameState.prestige || 0}</span>
                    </div>
                </div>
            </div>

            <h3 className="text-xs font-bold mb-6 text-gray-500 uppercase tracking-[0.3em] px-2">Personalization</h3>
            
            <div className="space-y-6">
                <div className="bg-white/2 border border-white/5 p-6 rounded-[32px]">
                    <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest block mb-4">Identity Title</span>
                    <div className="flex flex-wrap gap-2">
                        {TITLES.filter(t => gameState.totalResourcesMined >= t.minMined).map(title => (
                            <button 
                                key={title.id}
                                onClick={() => onUpdateProfile({ title: title.name })}
                                className={`px-4 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${gameState.profileCustomization.title === title.name ? 'bg-blue-600 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
                            >
                                {title.name}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="bg-white/2 border border-white/5 p-6 rounded-[32px]">
                    <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest block mb-4">Core Aura</span>
                    <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                        {colors.map(color => (
                            <button 
                                key={color}
                                onClick={() => onUpdateProfile({ avatarColor: color })}
                                className={`w-10 h-10 rounded-full shrink-0 transition-all ${gameState.profileCustomization.avatarColor === color ? 'ring-4 ring-white/20' : 'opacity-40 hover:opacity-100'}`}
                                style={{ backgroundColor: color }}
                            />
                        ))}
                    </div>
                </div>

                <div className="bg-white/2 border border-white/5 p-6 rounded-[32px]">
                    <span className="text-[10px] text-gray-500 uppercase font-bold tracking-widest block mb-4">Avatar Symbol</span>
                    <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                        {AVATAR_ICONS.map(item => (
                            <button 
                                key={item.id}
                                onClick={() => onUpdateProfile({ avatarIcon: item.id })}
                                className={`w-14 h-14 shrink-0 rounded-2xl flex items-center justify-center transition-all ${gameState.profileCustomization.avatarIcon === item.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' : 'bg-white/5 text-gray-500 hover:bg-white/10'}`}
                            >
                                <AvatarDisplay icon={item.id} />
                            </button>
                        ))}
                    </div>
                </div>
            </div>

            <InventorySummary gameState={gameState} />

            <div className="mt-8 flex flex-col items-center gap-4">
                {isGuest ? (
                    <button 
                        onClick={onExitGuest}
                        className="bg-white text-black px-8 py-4 rounded-[20px] text-xs font-black uppercase tracking-widest transition-all shadow-lg hover:shadow-white/20"
                    >
                        Exit Guest Session
                    </button>
                ) : (
                    <button 
                        onClick={onLogout}
                        className="bg-red-500/10 hover:bg-red-500 border border-red-500/20 text-red-500 hover:text-white px-8 py-4 rounded-[20px] text-xs font-black uppercase tracking-widest transition-all shadow-lg hover:shadow-red-500/20"
                    >
                        Deauthorize Account
                    </button>
                )}
            </div>
        </motion.div>
    );
}

function AIView({ gameState }: { gameState: UserData }) {
    const [messages, setMessages] = useState<{role: 'user' | 'ai', text: string}[]>([]);
    const [input, setInput] = useState('');
    const [isTyping, setIsTyping] = useState(false);

    const handleSend = async () => {
        if (!input.trim() || isTyping) return;
        
        const userMsg = input;
        setInput('');
        setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
        setIsTyping(true);

        const response = await askCaveAssistant(userMsg, gameState);
        setMessages(prev => [...prev, { role: 'ai', text: response }]);
        setIsTyping(false);
    };

    return (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="h-full flex flex-col p-6 max-h-[80vh]"
        >
            <div className="flex-1 overflow-y-auto space-y-4 mb-6">
                <div className="bg-blue-600/10 border border-blue-500/30 p-4 rounded-2xl">
                    <p className="text-sm">I am the Deep-Cave Hive Mind. Ask me about ores, luck, or system errors.</p>
                </div>
                {messages.map((m, i) => (
                    <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-4 rounded-2xl text-sm ${m.role === 'user' ? 'bg-blue-600' : 'bg-white/10 border border-white/5'}`}>
                            {m.text}
                        </div>
                    </div>
                ))}
                {isTyping && <div className="text-gray-500 text-xs italic">Hive mind processing...</div>}
            </div>

            <div className="flex gap-2">
                <input 
                  type="text" 
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="Query the hive..."
                  className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500"
                />
                <button 
                  onClick={handleSend}
                  className="bg-white text-black px-6 rounded-xl font-bold"
                >
                    Send
                </button>
            </div>
        </motion.div>
    );
}

function InventoryView({ gameState, onVault, onDevault }: { gameState: UserData, onVault: (type: string, amount: number) => void, onDevault: (type: string, amount: number) => void }) {
  const [vaultAmounts, setVaultAmounts] = useState<Record<string, number>>({});
  const [devaultAmounts, setDevaultAmounts] = useState<Record<string, number>>({});

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-6 pb-24">
      <h2 className="text-4xl font-bold mb-8 tracking-tighter">Inventory & Machine</h2>
      
      <h3 className="text-xs font-black uppercase tracking-[0.3em] text-blue-400 mb-6">In Backpack</h3>
      <div className="grid gap-4 mb-12">
        {Object.entries(gameState.resources).length === 0 || Object.entries(gameState.resources).filter(([_, count]) => (count as number) > 0).length === 0 ? (
            <div className="text-center p-12 bg-white/5 rounded-3xl border border-white/5">
                <Pickaxe className="w-12 h-12 text-gray-700 mx-auto mb-4" />
                <p className="text-gray-500 uppercase text-[10px] font-black tracking-widest">Backpack is empty</p>
            </div>
        ) : (
            Object.entries(gameState.resources).filter(([_, count]) => (count as number) > 0).map(([type, count]) => {
                const ore = ORES[type as keyof typeof ORES];
                const max = count as number;
                const currentVal = vaultAmounts[type] || max;

                return (
                    <div key={type} className="bg-white/5 p-6 rounded-3xl border border-white/5 flex flex-col gap-4">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-xl" style={{ backgroundColor: ore?.color }}></div>
                                <div>
                                    <span className="block font-bold">{ore?.name}</span>
                                    <span className="text-xs text-gray-500">{count} in pack</span>
                                    {gameState.mutations.length > 0 && (
                                        <div className="flex flex-wrap gap-1 mt-1">
                                            {gameState.mutations.map(mId => {
                                                const m = MUTATIONS.find(x => x.id === mId);
                                                return <span key={mId} className="text-[7px] text-purple-400 font-black uppercase tracking-widest bg-purple-500/10 px-1 rounded">{m?.name}</span>
                                            })}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <input 
                                type="range" 
                                min="1" 
                                max={max} 
                                value={currentVal}
                                onChange={(e) => setVaultAmounts(prev => ({ ...prev, [type]: parseInt(e.target.value) }))}
                                className="flex-1 accent-blue-500 h-1 bg-white/10 rounded-full appearance-none"
                            />
                            <span className="text-xs font-mono font-bold w-12 text-center">{currentVal}</span>
                            <button 
                                onClick={() => onVault(type, currentVal)}
                                className="bg-blue-600/20 text-blue-400 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all whitespace-nowrap"
                            >
                                Add to Crafting Machine
                            </button>
                        </div>
                    </div>
                );
            })
        )}
      </div>

      <h3 className="text-xs font-black uppercase tracking-[0.3em] text-purple-400 mb-6">Crafting Machine Storage</h3>
      <div className="grid gap-4">
        {Object.entries(gameState.vaultResources || {}).filter(([_, count]) => (count as number) > 0).length === 0 ? (
            <div className="text-center p-12 bg-white/5 rounded-3xl border border-white/5">
                <Archive className="w-12 h-12 text-gray-700 mx-auto mb-4" />
                <p className="text-gray-500 uppercase text-[10px] font-black tracking-widest">Machine is empty</p>
            </div>
        ) : (
            Object.entries(gameState.vaultResources || {}).filter(([_, count]) => (count as number) > 0).map(([type, count]) => {
                const ore = (ORES as any)[type];
                const max = count as number;
                const currentVal = devaultAmounts[type] || max;

                return (
                    <div key={type} className="bg-white/5 p-6 rounded-3xl border border-white/5 flex flex-col gap-4">
                        <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-xl" style={{ backgroundColor: ore?.color }}></div>
                                <div>
                                    <span className="block font-bold">{ore?.name}</span>
                                    <span className="text-xs text-gray-500">{count} in machine</span>
                                    {gameState.mutations.length > 0 && (
                                        <div className="flex flex-wrap gap-1 mt-1">
                                            {gameState.mutations.map(mId => {
                                                const m = MUTATIONS.find(x => x.id === mId);
                                                return <span key={mId} className="text-[7px] text-purple-400 font-black uppercase tracking-widest bg-purple-500/10 px-1 rounded">{m?.name}</span>
                                            })}
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center gap-4">
                            <input 
                                type="range" 
                                min="1" 
                                max={max} 
                                value={currentVal}
                                onChange={(e) => setDevaultAmounts(prev => ({ ...prev, [type]: parseInt(e.target.value) }))}
                                className="flex-1 accent-purple-500 h-1 bg-white/10 rounded-full appearance-none"
                            />
                            <span className="text-xs font-mono font-bold w-12 text-center">{currentVal}</span>
                            <button 
                                onClick={() => onDevault(type, currentVal)}
                                className="bg-purple-600/20 text-purple-400 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-purple-600 hover:text-white transition-all whitespace-nowrap"
                            >
                                Withdraw
                            </button>
                        </div>
                    </div>
                );
            })
        )}
      </div>
    </motion.div>
  );
}

function EventShopView({ gameState, activeEvents, onBuyEvent, onBuyMutation }: { gameState: UserData, activeEvents: any[], onBuyEvent: (id: string) => void, onBuyMutation: (id: string) => void }) {
  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-6 pb-24">
      <h2 className="text-4xl font-bold mb-2 tracking-tighter">Event Chaos</h2>
      <p className="text-gray-500 text-xs mb-8 uppercase font-bold tracking-widest">Stack events for ultimate power</p>

      <div className="grid gap-6">
        {EVENT_SHOP.map(item => {
            const event = EVENTS[item.id];
            const isActive = activeEvents.some(e => e.id === item.id);
            return (
                <div key={item.id} className="bg-white/5 rounded-[40px] p-8 border border-white/10 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 p-8">
                        <Zap className={`w-8 h-8 transition-all ${isActive ? 'text-yellow-400 scale-125' : 'text-gray-800 group-hover:text-gray-600'}`} />
                    </div>
                    <div className="relative z-10">
                        <span className="inline-block px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-[0.2em] mb-4" style={{ backgroundColor: `${event.color}20`, color: event.color }}>
                            {event.type.replace('_', ' ')}
                        </span>
                        <h3 className="text-2xl font-black mb-2">{event.name}</h3>
                        <p className="text-gray-500 text-xs mb-8 leading-relaxed max-w-[80%]">{event.description}</p>
                        
                        <button 
                            onClick={() => onBuyEvent(item.id)}
                            disabled={gameState.money < item.cost}
                            className={`w-full py-5 rounded-2xl font-black uppercase tracking-[0.3em] text-[10px] transition-all ${gameState.money >= item.cost ? 'bg-white text-black hover:scale-[1.02] active:scale-95 shadow-xl shadow-white/5' : 'bg-white/5 text-gray-700 cursor-not-allowed'}`}
                        >
                            Buy Event - ${item.cost.toLocaleString()}
                        </button>
                    </div>
                </div>
            );
        })}
      </div>

      <h3 className="text-xs font-black uppercase tracking-[0.3em] text-purple-400 mt-12 mb-6">Rare Mutations Shop</h3>
      <div className="grid gap-4">
          {MUTATIONS.map(m => {
              const owned = (gameState.mutations ?? []).includes(m.id);
              return (
                  <div key={m.id} className={`p-6 rounded-3xl border ${owned ? 'bg-purple-900/10 border-purple-500/20' : 'bg-white/5 border-white/10'}`}>
                      <div className="flex justify-between items-start mb-4">
                          <div>
                            <h4 className="font-bold">{m.name}</h4>
                            <p className="text-[10px] text-gray-500">{m.description}</p>
                          </div>
                      </div>
                      <button 
                        onClick={() => onBuyMutation(m.id)}
                        disabled={owned || gameState.money < m.cost}
                        className={`w-full py-3 rounded-xl font-black uppercase text-[10px] tracking-widest ${owned ? 'bg-purple-600/20 text-purple-400' : gameState.money >= m.cost ? 'bg-purple-600 text-white' : 'bg-white/5 text-gray-700'}`}
                      >
                          {owned ? 'OWNED' : `BUY - $${m.cost.toLocaleString()}`}
                      </button>
                  </div>
              )
          })}
      </div>

      <div className="mt-12 bg-purple-600/10 border border-purple-500/20 p-8 rounded-[40px]">
        <h4 className="text-purple-400 font-black uppercase tracking-[0.4em] text-[10px] mb-4">Active Mutations</h4>
        <div className="flex flex-wrap gap-2">
            {(gameState.mutations ?? []).length === 0 ? (
                <p className="text-gray-700 text-[10px] uppercase font-bold">No mutations found underground</p>
            ) : (
                (gameState.mutations ?? []).map(mId => {
                    const m = MUTATIONS.find(x => x.id === mId);
                    return (
                        <div key={mId} className="bg-purple-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest">
                            {m?.name}
                        </div>
                    );
                })
            )}
        </div>
      </div>
    </motion.div>
  );
}

